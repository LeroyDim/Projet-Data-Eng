# Projet Data-Eng

Hello,

To use our project you have to create your own developper account on Spotify. Once your account created, go to your dashboard and create a project no matter how you call it. 
Then go to your project and you have different things to do :

    -copy your Client ID and your Client Secret to the file conf.json like this :
        {
            "id" : "CLIENT ID",
            "secret": "CLIENT SECRET",
            "username" : "USERNAME"
        }
    
    -Go to edit setting and add 'http://127.0.0.1:8081/callback/' to your redirect URL. 

This project was inspired by many different projects, ideas from forums, websites here are the links :
    -https://spotipy.readthedocs.io/en/2.16.1/
    -https://flask.palletsprojects.com/en/1.1.x/installation/
    -https://towardsdatascience.com/using-python-to-refine-your-spotify-recommendations-6dc08bcf408e (not very present in the project due to our incapcity to make it work)
    -https://stmorse.github.io/journal/spotify-api.html
    -https://github.com/mari-linhares/spotify-flask
    -https://developer.spotify.com/documentation/general/guides/authorization-guide/
    -https://github.com/drshrey/spotify-flask-auth-example 
    -http://www.erwanlenagard.com/musique/creer-une-playlist-de-recommandations-spotify-1341
   
